/*main() {
  int a = 10;

  final personas = [
    'Fernando',

    'Daniel',

    'Carlos'
  ];'
}

saludar(int a, int b){}
Se recomienda usaer esta menera para comentar el codigo para documentacion del proyecto
*/
