main() {
  var a = 15;
  final double b = 15;
  const double c = 15;

  late final double
  x; //Late para definir la variables despues, siempre y cuando usemos final.
  x = 10; //efecto late

  print(x);

  //final personasFinal = ['Andres', 'Felipe', 'John'];
  //const personasConst = ['Andres', 'Felipe', 'John'];
  final List<String> personasFinal = ['Andres', 'Felipe', 'John'];
  List<String> personasConst = const ['Andres', 'Felipe', 'John'];

  personasFinal.add('Zara');
  //personasConst.add('Zara');

  //print(personasConst);
}
