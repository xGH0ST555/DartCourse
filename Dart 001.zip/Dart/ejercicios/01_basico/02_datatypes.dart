main(){

  //Numeros
  int a = 10;
  double b = 5.5;
   int? c; 
   int _a = 30;
   double $b = 40;

   double resultado = _a + $b;
   
  //print(resultado);


  //Strings
  String msg = 'Hola';
  String msg2 = "Hola";
  String msg3 = "O'Riley";
  String apellido = 'Valencia';
  String nombreCompleto = '$msg3 $apellido';

    //print(nombreCompleto);

  String multilinea = '''
  Hola $nombreCompleto
  Estoy programando
  En Dart.''';
    //print(multilinea);

  //Booleanos

    bool isActive = true;
    bool isNotActive = !isActive; 

    //print (isNotActive); 

  //Listas == Lists
  //List<String> villanos = new List.empty();
  String sample = 'Kanyenot heroe';
 List<String> heroes = ['Superman', 'Jesus', 'hulk', '$sample'];

  heroes[0] = 'Batman';
  heroes[2] = 'Dios';
  heroes.add(nombreCompleto);

  //print(heroes);

  //Sets
  Set<String> villanos = {'doom', 'devil', 'judas'};

  villanos.add('Tom');

  //print(villanos);

  //Maps
  Map<int, dynamic> dark = {
    1: 'Daniel',
    2: 'Fuerza',
    3:  70000
  };

  //print(dark[1]);
  Map<String, dynamic> lider = new Map();
  lider.addAll({
    'nombre': 'Andres',
    'poder': 'Dormir',
    'nivel': 60
  });
  //lider.addAll(dark);

  print(lider);

} 