main() {
  /*int edad;
  double peso;
  String nombre;
  bool Estudiante;

  num numero = 14;
  numero = 1.4;
  */

  /*  List<dynamic> numeros = [1, 2, 3, 4, 5, 6];
  numeros.add(5);
  numeros.add('regina');
  numeros.add(true);

  print(numeros);

  Map<String, int> mapa = {'Punto ': 1, 'coma': 2};
  print(mapa);
*/

  /* String? apodo;
  apodo = 'mandu';
  apodo = null;
  print(apodo);

  String valle = 'spo';
  String? azul;
  String? rojo =
      valle ??
      azul; // ?? compara las variables e imprme el resulta do de la variable que NO es nula.
  //en casao de que una de las dos no lo sea
  //print(rojo);

  List<int> enteros;
  enteros = [1, 2, 3];
  enteros.remove(1); //Remueve el valor literal... no se basa en la posicion
  print(enteros);
  */
  /*
  List<String> usuarios;
  List<bool>? usuarioActivo = [true, false, false];
  usuarios = ['Andres', 'Felipe', 'Daniel'];
  for (var i = 0; i < usuarios.length; i++) {
    if (usuarioActivo[i] == true) {
      print('usuario activo: ' + usuarios[0]);
    } else {
      print('usuario ' + usuarios[i] + ' no esta activo');
    }
  }*/

  /* double promedio;
  double nota1 = 5;
  double nota2 = 3.2;
  double nota3 = 2.7;

  promedio = (nota1 + nota2 + nota3) / 3;
  //print('Su promedio final es: $promedio');

  double numero = 5;

  if (numero % 2 == 0) {
    //Pares Los cuales dividiendose entre 2 su residuo es 0 de ahí la expresion (numero % 2 == 0)
    print('el numero $numero es par');
  }
  else{
    print('el numero $numero es impar');
  }*/

/*
  double horasTrabajo = 55;
  double salarioXh = 10;
  double horasExtra = 15;
  double sueldo = 0;

  double valortotalhoras = 0.0;
  double valortotalhoraextra = 0.0;

  if (horasTrabajo <= 40) {
    sueldo = horasTrabajo * salarioXh;
  } else if (horasTrabajo > 40) {

    valortotalhoras = horasTrabajo * 10;
    valortotalhoraextra = horasExtra * 15;

    sueldo = valortotalhoras+valortotalhoraextra ;
  }

  print('Este sera tu sueldo segun tu horas trabajadas: $sueldo');*/

}
