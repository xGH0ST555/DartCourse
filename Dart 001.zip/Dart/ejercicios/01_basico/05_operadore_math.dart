main() {
  int a = 10 + 5;
  a = 20 - 10;
  a = 10 * 2;

  double b = 10 / 2;
  b = 10 % 3; //el resultado es el residuo de la division sintetica
  b = -b; //Se utilizado para cambiar el valor de la expresion

  int c =
      10 ~/
      3; //Division comun pero da la parte enterea de este caso un numero periodico

  int d = 1;
  d++; //incrementa en 1 en valor
  d--; //decrementa el valor en 1

  d += 2; //se incrementa en 2 y asi sucesivamente
  d -= 2; //Se decrementa en 2 y asi sucesivamente
}
