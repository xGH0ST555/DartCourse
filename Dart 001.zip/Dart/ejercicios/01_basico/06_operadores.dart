main() {
  //operadores de asignacion
  int? a; //= 20;

  int? b; // = 2; ?junto al tipo indica que la variable sera nula

  //operaciones condicionales
  int c = 28;
  String resp = c > 25
      ? 'C es mayor a 25'
      : 'C es menor a 25'; //Condicional ternario

  //print(resp);
  int? d = b ?? a; //Al tener la otras dos variables nulas al definir esta dandole equivalencia de las anteriores tambien nulas
  //se debe definir como nula tambien
  //print(d);

  // Operaciones relacionales

  /*
    < Menor que
    > Mayor que

    <= Menor igual que
    >= Mayor igual que

    == Revisa si dos objetos son iguales
    != Revisa si dos objetos son diferente util para contraseñas
  */

  String persona1 = 'Fernando';
  String persona2 = 'Daniel';

  //print(persona1 == persona2);
  //print(persona1 != persona2);

  int x = 20;
  int y = 20;

  // print(x > y);
  // print(x < y);
  // print(x >= y);
  // print(x <= y);

  //Operador de tipo

  int i = 10;
  String j = '10';

  print(i is int);
  print(j is int);
}
