main(){

  print('Hi world');

}